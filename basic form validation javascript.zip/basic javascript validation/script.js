function validateform() {
  let valid = true;

  let name_data = {
    first_name: "firstname",
    last_name: "lastname",
    Email: "email",
    Phone_No: "phone_number",
    message: "msg",
  };
  let value = Object.values(name_data);

  for (let i of value) {
    var val = i;
    let x = document.forms["contactus"][i].value;
    if (x == "") {
      alert("please fill the" + " " + val);
      valid = false;
      break;
    } else if (val == "phone_number") {
      let x_len = x.length;
      alert(x_len);
      if (x_len == 10) {
        valid == true;
      } else {
        alert("Phone no is not valid");
        valid = false;
      }
    }
  }

  return valid;
}
