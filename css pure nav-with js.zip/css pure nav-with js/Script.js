// document.addEventListener(
//   "DOMContentLoaded",
//   function () {
//     var button = document.createElement("button");
//     button.type = "button";
//     button.innerHTML = "Press me";
//     button.className = "btn-styled";
//     button.id = "hi";

//     button.onclick = function () {
//       alert("yye");
//     };

//     var container = document.getElementById("container");
//     container.appendChild(button);
//   },
//   false
// );

// document.getElementById("container").addEventListener("click", function (e) {
//   if (e.target.matches("#hi")) {
//     alert("yy");
//   }
// });

function toggleHandler() {
  const menu = document.getElementById("main-nav-menu-id");

  menu.style.backgroundColor = "red !important";

  menu.classList.toggle("d-block");
}
